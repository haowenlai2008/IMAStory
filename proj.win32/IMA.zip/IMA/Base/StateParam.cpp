#include "StateParam.h"



StateParam::StateParam()
{
}


StateParam::~StateParam()
{
}

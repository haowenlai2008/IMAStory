#pragma once
class StateParam
{
public:
	StateParam();
	~StateParam();

};


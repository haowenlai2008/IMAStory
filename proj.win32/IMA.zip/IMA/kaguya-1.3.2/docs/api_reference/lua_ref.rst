
LuaRef
==================================

.. doxygenclass:: kaguya::LuaRef
  :members:


LuaUserData
==================================

.. doxygenclass:: kaguya::LuaUserData
  :members:

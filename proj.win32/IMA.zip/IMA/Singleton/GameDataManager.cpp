#include "GameDataManager.h"
#include <fstream>
#include "GameManager.h"
#include "DBUtil.h"
#include "json.h"
//#include "Useful.h"
#pragma execution_character_set("utf-8")
GameDataManager* GameDataManager::m_dataManager = NULL;
GameDataManager * GameDataManager::getInstance()
{
	if (!m_dataManager)
	{
		m_dataManager = new(std::nothrow) GameDataManager();
		m_dataManager->init();
	}
	return m_dataManager;
}


bool GameDataManager::init()
{
	this->retain();
	writeNPCData();
	//writeArchiceData();
	readMapData();
	readArchice(0);
	readNPCData();
	dataBaseInit();
	return true;
}

void GameDataManager::writeMapData()
{
	Json::FastWriter writer;
	Json::Value root;
	root["map"][std::move(0)]["left"] = 0xff;
	root["map"][std::move(0)]["right"] = 1;
	root["map"][std::move(0)]["refresh"] = false;
	root["map"][std::move(0)]["MonsterID"] = 0xff;
	root["map"][std::move(0)]["name"] = "Villae.tmx";
	root["map"][std::move(1)]["left"] = 0;
	root["map"][std::move(1)]["right"] = 2;
	root["map"][std::move(1)]["refresh"] = true;
	root["map"][std::move(1)]["MonsterID"] = 1;
	root["map"][std::move(1)]["name"] = "Egg.tmx";
	root["map"][std::move(2)]["left"] = 1;
	root["map"][std::move(2)]["right"] = 3;
	root["map"][std::move(2)]["refresh"] = false;
	root["map"][std::move(2)]["MonsterID"] = 0xff;
	root["map"][std::move(2)]["name"] = "Egg.tmx";
	root["map"][std::move(3)]["left"] = 2;
	root["map"][std::move(3)]["right"] = 0xff;
	root["map"][std::move(3)]["refresh"] = true;
	root["map"][std::move(3)]["MonsterID"] = 1;
	root["map"][std::move(3)]["name"] = "Egg.tmx";

	
	std::ofstream out("MapData.json", std::ios::binary);
	if (out.is_open())
	{
		std::string data = writer.write(root);
		out << data;
		log("��ͼ����д��ɹ�");
	}
	else
	{
		log("��ͼ�ļ��򿪴���");
	}
	out.close();
}

void GameDataManager::writeArchiceData()
{
	Json::FastWriter writer;
	Json::Value root;
	root["Archice"][std::move(0)]["HP"] = 1000;
	root["Archice"][std::move(0)]["Level"] = 1;
	root["Archice"][std::move(0)]["EXP"] = 100;
	root["Archice"][std::move(0)]["MapID"] = 0;

	std::ofstream out("Archice.json", std::ios::binary);
	if (out.is_open())
	{
		std::string data = writer.write(root);
		out << data;
		log(u8"�浵����д��ɹ�");
	}
	else
	{
		log("�浵�ļ��򿪴���");
	}
	out.close();
}

void GameDataManager::writeNPCData()
{
	Json::FastWriter writer;
	Json::Value root;
	root["NPC"][std::move(0)]["ID"] = 0;
	root["NPC"][std::move(0)]["MapID"] = 0;
	root["NPC"][std::move(0)]["position_x"] = 600;
	root["NPC"][std::move(0)]["position_y"] = 300;
	root["NPC"][std::move(0)]["exist"] = true;
	root["NPC"][std::move(0)]["Name"] = "Frost";
	root["NPC"][std::move(0)]["TextureName"] = "MainHeroine.png";

	root["NPC"][std::move(1)]["ID"] = 1;
	root["NPC"][std::move(1)]["MapID"] = 2;
	root["NPC"][std::move(1)]["position_x"] = 400;
	root["NPC"][std::move(1)]["position_y"] = 300;
	root["NPC"][std::move(1)]["exist"] = false;
	root["NPC"][std::move(1)]["Name"] = "DarkKnight";
	root["NPC"][std::move(1)]["TextureName"] = "DarkKnight.png";
	std::ofstream out("NPC.json", std::ios::binary);
	if (out.is_open())
	{
		std::string data = writer.write(root);
		out << data;
		log(u8"NPC����д��ɹ�");
	}
	else
	{
		log("NPC�ļ��򿪴���");
	}
	out.close();
}

void GameDataManager::readMapData()
{
	Json::Value root;
	Json::Reader reader;
	std::ifstream in("MapData.json", std::ios::binary);
	mapmsg.clear();
	if (!in.is_open())
	{
		return;
	}
	if (reader.parse(in, root, false) == true)
	{
		int size = root["map"].size();
		for (int i = 0; i < size; i++)
		{
			int left = root["map"][i]["left"].asInt();
			int right = root["map"][i]["right"].asInt();
			int MonsterID = root["map"][i]["MonsterID"].asInt();
			bool refresh = root["map"][i]["refresh"].asBool();
			std::string name = root["map"][i]["name"].asString();
			mapmsg.push_back(MapMsg(left, right, MonsterID, refresh, name));
			log("��%dͼ: ��:%d, ��:%d, ����:%d, refresh:%d, name:%s", i, left, right, MonsterID, refresh, name.c_str());
		}
		log(u8"��ͼ���ݶ�ȡ�ɹ�");
	}
	in.close();
}

void GameDataManager::readArchice(int ArchiceNum)
{
	Json::Value root;
	Json::Reader reader;
	std::ifstream in("Archice.json", std::ios::binary);
	if (!in.is_open())
	{
		return;
	}
	if (reader.parse(in, root, false) == true)
	{
		archiceData.HP = root["Archice"][std::move(ArchiceNum)]["HP"].asInt();
		archiceData.Level = root["Archice"][std::move(ArchiceNum)]["Level"].asInt();
		archiceData.EXP = root["Archice"][std::move(ArchiceNum)]["EXP"].asInt();
		archiceData.MapID = root["Archice"][std::move(ArchiceNum)]["MapID"].asInt();
		log("�浵��ȡ�ɹ�");
	}
	in.close();
}

void GameDataManager::readNPCData()
{
	Json::Value root;
	Json::Reader reader;
	std::ifstream in("NPC.json", std::ios::binary);
	NPCDataMsg.clear();
	if (!in.is_open())
	{
		return;
	}
	if (reader.parse(in, root, false) == true)
	{
		int size = root["NPC"].size();
		for (int i = 0; i < size; i++)
		{
			int id = root["NPC"][i]["ID"].asInt();
			int mapid = root["NPC"][i]["MapID"].asInt();
			float x = root["NPC"][i]["position_x"].asDouble();
			float y = root["NPC"][i]["position_y"].asDouble();
			bool exist = root["NPC"][i]["exist"].asBool();
			string name = root["NPC"][i]["Name"].asString();
			string texture = root["NPC"][i]["TextureName"].asString();
			NPCDataMsg.push_back(NPCData(id, mapid, x, y, exist, name, texture));
		}
		log(u8"NPC���ݶ�ȡ�ɹ�");
	}
	in.close();
}

void GameDataManager::ArchiceInit()
{
}

void GameDataManager::dataBaseInit()
{
	
#ifdef DATA_DEBUG

#endif // DATA_DEBUG
}

void GameDataManager::dataUpdate()
{

}

//�������ݣ����¿�ʼ��Ϸ��
void GameDataManager::dataReset()
{
	writeNPCData();
	writeArchiceData();
	readMapData();
	readArchice(0);
	readNPCData();
	dataUpdate();
}

void GameDataManager::toLeft()
{
	if (archiceData.MapID > 0)
		archiceData.MapID -= 1;
}

void GameDataManager::toRight()
{
	if (archiceData.MapID < 3)
		archiceData.MapID += 1;
}

void GameDataManager::unLoad()
{
	this->release();
}

bool GameDataManager::getMonsterRefreshState()
{
	return mapmsg[archiceData.MapID].Refresh;
}

int GameDataManager::getLessMapID()
{
	return 0;
}

int GameDataManager::getMaxMapID()
{
	return mapmsg.size() - 1;
}

int GameDataManager::getRecentMapID()
{
	return archiceData.MapID;
}

int GameDataManager::getLeftMapID()
{
	return mapmsg[getRecentMapID()].LeftMapID;
}

int GameDataManager::getRightMapID()
{
	return mapmsg[getRecentMapID()].RightMapID;
}

std::string & GameDataManager::getRecentMap()
{
	return mapmsg[archiceData.MapID].Name;
}

std::string & GameDataManager::getLeftMap()
{
	return mapmsg[getLeftMapID()].Name;
}

std::string & GameDataManager::getRightMap()
{
	return mapmsg[getRightMapID()].Name;
}

std::string & GameDataManager::getMonsterName()
{
	//return mapmsg[archiceData.MapID].MonsterID
	return std::string();
}

ArchiceData GameDataManager::getArchiceData()
{
	return archiceData;
}

NPCData GameDataManager::getNPCData(int ID)
{
	if (ID >= NPCDataMsg.size() || ID < 0)
		return NPCData();
	return NPCDataMsg[ID];
}

